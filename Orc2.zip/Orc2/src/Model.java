import java.util.Random;
/**
 * Model: Contains all the state and logic
 * Does not contain anything about images or graphics, must ask view for that
 *
 * has methods to
 *  detect collision with boundaries
 * decide next direction
 * provide direction
 * provide location
 **/
public class Model{
	private int height;
	private int width;
	private int imaHeight;
	private int imaWidth;
	private int x = 0;
	private int y = 0;
	final int xIncr = 20;   //8
    final int yIncr = 15;   // 2
	private Direction direct;
	Direction[] enums = new Direction[] {Direction.EAST,Direction.NORTH,Direction.NORTHEAST,
							   Direction.NORTHWEST,Direction.SOUTH,Direction.SOUTHEAST,
							   Direction.SOUTHWEST,Direction.WEST};
	
	public Model(int width, int height, int imaHeight, int imaWidth) {
		this.height = height;
		this.width = width;
		this.imaHeight = imaHeight;
		this.imaWidth = imaWidth;
		this.x = x;
		this.y = y;
		this.direct = Direction.SOUTHEAST;
	}
	
	public void updateLocationAndDirection() {
		if (direct.getName().contains("east")) {
    		if (x <= width - imaWidth) {
    			x+= xIncr;
    		}
    		else {
    			getDirect("east");
    		}
    	}
    	else if (direct.getName().contains("west")){
    		if (x >= 0) {
    			x -= xIncr;
    		}
    		else {
    			getDirect("west");
    		}
    	}
		if (direct.getName().contains("south")) {
    		if (y <= height - imaHeight) {
    			y += yIncr;
    		}
    		else {
    			getDirect("south");
    		}
    	}
    	else if (direct.getName().contains("north")){
    		if (y > 0) {
    			y -= yIncr;
    		}
    		else {
    			getDirect("north");
    		}
    	}
	};
	
	
	
	public void getDirect(String hit) {
    	
    	Random random = new Random();
    	Direction d =enums[Math.abs(random.nextInt()) % enums.length];
    	if (d.getName().contains(hit)) {      // two version  x.contains(a) || x.contains(b)
    		getDirect(hit);
    	}
    	else {
    		direct = d;
    		//System.out.println(direction);
    		return;
    	}
    }
	
	public Direction getDirect() {
		return this.direct;
	}
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	
}