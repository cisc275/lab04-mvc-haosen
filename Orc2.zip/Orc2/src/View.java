import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * View: Contains everything about graphics and images
 * Know size of world, which images to load etc
 *
 * has methods to
 * provide boundaries
 * use proper images for direction
 * load images for all direction (an image should only be loaded once!!! why?)
 **/

public class View extends JPanel{
	final  int frameWidth = 500; 
    final  int frameHeight = 300;
    final  int imaWidth = 165;
    final  int imaHeight = 165;
    int picNum = 0;
    final int frameCount = 10;
    private Map<String,BufferedImage[]> map;
	BufferedImage Img;
	JFrame frame = new JFrame();
	
	//Graphics g;
	int x;
	int y;
	
	public View() {
		
		map = new HashMap<>();
		String[] imaKeys = {"se", "sw", "ne", "nw","n","s","w","e"};
    	for(int i = 0; i < 8; i++) {
    		BufferedImage img = createImage(imaKeys[i]);
    		BufferedImage[] imgs = new BufferedImage[10];
    		for(int j = 0; j < frameCount; j++) {
        		imas[j] = ima.getSubimage(imaWidth*j, 0, imaWidth, imaHeight);
    		}
    		map.put(imgKeys[i], imgs);
    	}
    	frame.getContentPane().add(this);
    	frame.setBackground(Color.gray);
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(frameWidth, frameHeight);
    	frame.setVisible(true);

	}
	
    public void paint(Graphics g) {
    	g.drawImage(Img, x, y, Color.gray, this);
    }
	
	public int getHeight() {
		return this.frameHeight;
	}
	
	public int getWidth() {
		return this.frameWidth;
	}
	
	public int getImageHeight() {
		return this.imgHeight;
	}
	
	public int getImageWidth() {
		return this.imgWidth;
	}
	
	public void update(int x, int y, Direction d) {
		picNum = (picNum + 1) % frameCount; 

		if (d.getName().equals("southeast")) {
    		Img = map.get("se")[picNum];
    	}
    	else if (d.getName().equals("southwest")) {
    		Img = map.get("sw")[picNum];
    	}
    	else if (d.getName().equals("northeast")) {
    		Img = map.get("ne")[picNum]; 
    	}
    	else if (d.getName().equals("northwest")){
    		Img =  map.get("nw")[picNum];
    	}
    	else if (d.getName().equals("north")) {
    		Img =  map.get("n")[picNum];
    	}
    	else if (d.getName().equals("south")) {
    		Img =  map.get("s")[picNum];
    	}
    	else if (d.getName().equals("east")) {
    		Img = map.get("e")[picNum];
    	}
    	else {
    		Img =  map.get("w")[picNum];
    	}
		
		this.x = x;
		this.y = y;
		
		frame.repaint();
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	private BufferedImage createImage(String x){
    	BufferedImage bufferedImage;
    	try {
    		if (x.equals("se")) {
    			bufferedImage = ImageIO.read(new File("src/orc_animation/orc_forward_southeast.png"));
    		}
    		else if (x.equals("ne")) {
    			bufferedImage = ImageIO.read(new File("src/orc_animation/orc_forward_northeast.png"));
    		}
    		else if (x.equals("sw")) {
    			bufferedImage = ImageIO.read(new File("src/orc_animation/orc_forward_southwest.png"));
    		}
    		else if (x.equals("nw")){
    			bufferedImage = ImageIO.read(new File("src/orc_animation/orc_forward_northwest.png"));
    		}
    		else if (x.equals("n")) {
    			bufferedImage = ImageIO.read(new File("src/orc_animation/orc_forward_north.png"));
    		}
    		else if (x.equals("s")) {
    			bufferedImage = ImageIO.read(new File("src/orc_animation/orc_forward_south.png"));
    		}
    		else if (x.equals("w")) {
    			bufferedImage = ImageIO.read(new File("src/orc_animation/orc_forward_west.png"));
    		}
    		else {
    			bufferedImage = ImageIO.read(new File("src/orc_animation/orc_forward_east.png"));
    		}
    		//bufferedImage = ImageIO.read(new File("src/images/orc/orc_forward_southeast.png"));
    		return bufferedImage;
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
    	return null;
    	
    	
    	
    	// TODO: Change this method so you can load other orc animation bitmaps
    }
	
}
